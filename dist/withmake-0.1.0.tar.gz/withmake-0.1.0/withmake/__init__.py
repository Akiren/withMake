# This line of code will allow shorter imports
from withmake.script import WithMake
